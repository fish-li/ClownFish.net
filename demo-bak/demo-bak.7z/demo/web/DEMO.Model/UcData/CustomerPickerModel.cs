﻿using System.Collections.Generic;


namespace DEMO.Model
{
	public class CustomerPickerModel
	{
		public CustomerSearchInfo SearchInfo { get; set; }
		public List<Customer> List { get; set; }
	}


}
