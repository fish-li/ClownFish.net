﻿using System;
using System.Collections.Generic;



namespace DEMO.Model
{
	public class OrderListModel
	{
		public OrderSearchInfo SearchInfo { get; set; }
		public List<Order> List { get; set; }
	}


}