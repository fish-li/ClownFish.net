﻿using System.Collections.Generic;

namespace DEMO.Model
{
	public class CategoriesPageModel
	{
		public List<Category> List { get; set; }
	}


}