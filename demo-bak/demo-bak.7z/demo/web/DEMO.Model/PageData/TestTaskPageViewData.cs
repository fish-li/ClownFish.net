﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEMO.Model.PageData
{
	public class TestTaskPageViewData
	{
		public string Input { get; set; }

		public List<KeyValuePair<string, string>> Result { get; set; }
	}
}
