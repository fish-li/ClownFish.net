﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DEMO.Model.BigPipe
{
	/// <summary>
	///Comment 的摘要说明
	/// </summary>
	public class Comment
	{
		public string Title { get; set; }

		public string Text { get; set; }
	}
}
