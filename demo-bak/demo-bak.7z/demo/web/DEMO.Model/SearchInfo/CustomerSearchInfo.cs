﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClownFish;

namespace DEMO.Model
{
	public class CustomerSearchInfo : PagingInfo
	{
		public string SearchWord { get; set; }
	}
}
