﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DEMO.BLL
{
	public interface IDatabase
	{
		void AppStart();

		void AppEnd();
	}
}
